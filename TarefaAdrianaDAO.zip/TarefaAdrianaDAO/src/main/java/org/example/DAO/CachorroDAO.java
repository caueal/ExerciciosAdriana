package org.example.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.example.Classe.Cachorro;
import org.example.ConexaoBanco;

public class CachorroDAO {

    public void cadastrar(Cachorro cachorro) {
        String sql = "INSERT INTO cachorro (nome, raca, pelugem) VALUES (?, ?, ?)";
        //abre a conexão com o banco de dados e prepara a instrução SQL
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            //preenche o sql com os dados do cachorro
            stmt.setString(1, cachorro.getNome());
            stmt.setString(2, cachorro.getRaca());
            stmt.setString(3, cachorro.getPelugem());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void atualizar(Cachorro cachorro) {
        String sql = "UPDATE cachorro SET nome=?, raca=?, pelugem=? WHERE id=?";
        //abre a conexão com o banco de dados e prepara a instrução SQL
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            //preenche o sql com os dados do cachorro
            stmt.setString(1, cachorro.getNome());
            stmt.setString(2, cachorro.getRaca());
            stmt.setString(3, cachorro.getPelugem());
            stmt.setInt(4, cachorro.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluir(int id) {
        String sql = "DELETE FROM cachorro WHERE id=?";
        //abre a conexão com o banco de dados e prepara a instrução SQL
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            //preenche o sql com o id do cachorro a ser excluído
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Cachorro> listarTodos() {
        //cria uma lista para armazenar os cachorros
        List<Cachorro> lista = new ArrayList<>();
        String sql = "SELECT * FROM cachorro";
        //abre a conexão com o banco de dados e executa a consulta SQL
        try (Connection conexao = ConexaoBanco.obterConexao();
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            //percorre o resultado da consulta e adiciona cada cachorro à lista
            while (rs.next()) {
                lista.add(new Cachorro(rs.getInt("id"), rs.getString("nome"), rs.getString("raca"), rs.getString("pelugem")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //retorna a lista de cachorros
        return lista;
    }
}