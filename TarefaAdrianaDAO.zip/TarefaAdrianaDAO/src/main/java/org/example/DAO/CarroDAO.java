package org.example.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.example.Classe.Carro;
import org.example.ConexaoBanco;

public class CarroDAO {

    public void cadastrar(Carro carro) {
        String sql = "INSERT INTO Carro (modelo, fabricante, ano) VALUES (?, ?, ?)";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, carro.getModelo());
            stmt.setString(2, carro.getFabricante());
            stmt.setInt(3, carro.getAno());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public void atualizar(Carro carro) {
        String sql = "UPDATE carro SET modelo=?, fabricante=?, ano=? WHERE id=?";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, carro.getModelo());
            stmt.setString(2, carro.getFabricante());
            stmt.setInt(3, carro.getAno());
            stmt.setInt(4, carro.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluir(int id) {
        String sql = "DELETE FROM carro WHERE id=?";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Carro> listarTodos() {
        List<Carro> lista = new ArrayList<>();
        String sql = "SELECT * FROM carro";
        try (Connection conexao = ConexaoBanco.obterConexao();
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Carro(rs.getInt("id"), rs.getString("modelo"), rs.getString("fabricante"), rs.getInt("ano")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}