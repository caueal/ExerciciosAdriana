package org.example.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.example.Classe.Caneta;
import org.example.ConexaoBanco;

public class CanetaDAO {

    public void cadastrar(Caneta caneta) {
        String sql = "INSERT INTO caneta (cor, marca, preco) VALUES (?, ?, ?)";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, caneta.getCor());
            stmt.setString(2, caneta.getMarca());
            stmt.setDouble(3, caneta.getPreco());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public void atualizar(Caneta caneta) {
        String sql = "UPDATE caneta SET cor=?, marca=?, preco=? WHERE id=?";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, caneta.getCor());
            stmt.setString(2, caneta.getMarca());
            stmt.setDouble(3, caneta.getPreco());
            stmt.setInt(4, caneta.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluir(int id) {
        String sql = "DELETE FROM caneta WHERE id=?";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Caneta> listarTodos() {
        List<Caneta> lista = new ArrayList<>();
        String sql = "SELECT * FROM caneta";
        try (Connection conexao = ConexaoBanco.obterConexao();
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Caneta(rs.getInt("id"), rs.getString("cor"), rs.getString("marca"), rs.getDouble("preco")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}