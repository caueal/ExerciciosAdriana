package org.example.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.example.Classe.Instrumento;
import org.example.ConexaoBanco;

public class InstrumentoDAO {

    public void cadastrar(Instrumento instrumento) {
        String sql = "INSERT INTO instrumento (tipo, material, preco) VALUES (?, ?, ?)";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, instrumento.getTipo());
            stmt.setString(2, instrumento.getMaterial());
            stmt.setDouble(3, instrumento.getPreco());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void atualizar(Instrumento instrumento) {
        String sql = "UPDATE instrumento SET tipo=?, material=?, preco=? WHERE id=?";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1,instrumento.getTipo());
            stmt.setString(2,instrumento.getMaterial());
            stmt.setDouble(3,instrumento.getPreco());
            stmt.setInt(4,instrumento.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluir(int id) {
        String sql = "DELETE FROM instrumento WHERE id=?";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Instrumento> listarTodos() {
        List<Instrumento> lista = new ArrayList<>();
        String sql = "SELECT * FROM instrumento";
        try (Connection conexao = ConexaoBanco.obterConexao();
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Instrumento(rs.getInt("id"), rs.getString("tipo"), rs.getString("material"), rs.getDouble("preco")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}