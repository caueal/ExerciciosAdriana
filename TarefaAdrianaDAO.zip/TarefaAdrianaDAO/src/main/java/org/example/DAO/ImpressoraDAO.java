package org.example.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.example.Classe.Impressora;
import org.example.ConexaoBanco;

public class ImpressoraDAO {

    public void cadastrar(Impressora impressora) {
        String sql = "INSERT INTO impressora (modelo, papel, preco) VALUES (?, ?, ?)";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, impressora.getModelo());
            stmt.setString(2, impressora.getPapel());
            stmt.setInt(3, impressora.getPreco());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void atualizar(Impressora impressora) {
        String sql = "UPDATE impressora SET modelo=?, papel=?, preco=? WHERE id=?";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1,impressora.getModelo());
            stmt.setString(2,impressora.getPapel());
            stmt.setInt(3,impressora.getPreco());
            stmt.setInt(4,impressora.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluir(int id) {
        String sql = "DELETE FROM impressora WHERE id=?";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Impressora> listarTodos() {
        List<Impressora> lista = new ArrayList<>();
        String sql = "SELECT * FROM impressora";
        try (Connection conexao = ConexaoBanco.obterConexao();
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Impressora(rs.getInt("id"), rs.getString("modelo"), rs.getString("papel"), rs.getInt("preco")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}