package org.example.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.App;
import org.example.Classe.Carro;
import org.example.DAO.CarroDAO;

import java.io.IOException;

import static org.example.ExibirAlerta.exibirAlerta;

public class CarroController {

 @FXML
    private Button btnAlterar;

    @FXML
    private Button btnAtualizar;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Button btnExcluirCac;

    @FXML
    private Button btn_menu;

    @FXML
    private TableColumn<Carro, Integer> colId;

    @FXML
    private TableColumn<Carro, String> colModelo;

    @FXML
    private TableColumn<Carro, String> colFabricante;

    @FXML
    private TableColumn<Carro, Integer> colAno;

    @FXML
    private TableView<Carro> tableCarro;

    @FXML
    private TextField txtModelo;

    @FXML
    private TextField txtFabricante;

    @FXML
    private TextField txtAno;

    private ObservableList<Carro> ListaCarro = FXCollections.observableArrayList();
    private CarroDAO carroDAO = new CarroDAO();

    @FXML
    private void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colModelo.setCellValueFactory(new PropertyValueFactory<>("modelo"));
        colFabricante.setCellValueFactory(new PropertyValueFactory<>("fabricante"));
        colAno.setCellValueFactory(new PropertyValueFactory<>("ano"));

        ListaCarro.setAll(carroDAO.listarTodos());
        tableCarro.setItems(ListaCarro);
    }

    @FXML
    void Cadastrar(ActionEvent event) {
        try {
            String modelo = txtModelo.getText();
            String fabricante = txtFabricante.getText();
            String ano = txtAno.getText();

            Carro novoCarro = new Carro(0, modelo, fabricante, Integer.parseInt(ano));
            carroDAO.cadastrar(novoCarro);
            atualizarListaCarro();

            txtModelo.clear();
            txtFabricante.clear();
            txtAno.clear();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Carro salvo");
        } catch (NumberFormatException e) {
            exibirAlerta(Alert.AlertType.ERROR, "Erro", "Prencha todo os Campos");
        }
    }

    @FXML
    void Excluir(ActionEvent event) {
        Carro selecionado = tableCarro.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            carroDAO.excluir(selecionado.getId());
            atualizarListaCarro();
            exibirAlerta(Alert.AlertType.INFORMATION, "Carro excluido", "");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione um Carro");
        }
        }

    @FXML
    void Alterar(ActionEvent event) {
        Carro selecionado = tableCarro.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            txtModelo.setText(selecionado.getModelo());
            txtFabricante.setText(selecionado.getFabricante());
            txtAno.setText(String.valueOf(selecionado.getAno()));
        }
        else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione um Carro.");
        }

    }
    
    @FXML
    void Atualizar(ActionEvent event) {
        Carro selecionado = tableCarro.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            selecionado.setModelo(txtModelo.getText());
            selecionado.setFabricante(txtFabricante.getText());
            selecionado.setAno(Integer.parseInt(txtAno.getText()));

            carroDAO.atualizar(selecionado);
            atualizarListaCarro();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Carro atualizado");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Erro", "Selecione um carro");
        }
        }

    @FXML
    void MostrarMenu(ActionEvent event) throws IOException {
        App.setRoot("menu");

    }

    private void atualizarListaCarro() {
        ListaCarro.setAll(carroDAO.listarTodos());
        tableCarro.refresh();
    }
} 