package org.example.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.App;
import org.example.Classe.Ferramenta;
import org.example.DAO.FerramentaDAO;

import java.io.IOException;

import static org.example.ExibirAlerta.exibirAlerta;

public class FerramentaController {

 @FXML
    private Button btnAlterar;

    @FXML
    private Button btnAtualizar;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Button btnExcluirCac;

    @FXML
    private Button btn_menu;

    @FXML
    private TableColumn<Ferramenta, Integer> colId;

    @FXML
    private TableColumn<Ferramenta, String> colTipo;

    @FXML
    private TableColumn<Ferramenta, String> colMarca;

    @FXML
    private TableColumn<Ferramenta, String> colFuncao;

    @FXML
    private TableView<Ferramenta> tableFerramenta;

    @FXML
    private TextField txtTipo;

    @FXML
    private TextField txtMarca;

    @FXML
    private TextField txtFuncao;

    private ObservableList<Ferramenta> ListaFerramenta = FXCollections.observableArrayList();
    private FerramentaDAO ferramentaDAO = new FerramentaDAO();

    @FXML
    private void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTipo.setCellValueFactory(new PropertyValueFactory<>("tipof"));
        colMarca.setCellValueFactory(new PropertyValueFactory<>("marcaf"));
        colFuncao.setCellValueFactory(new PropertyValueFactory<>("funcao")); 

        ListaFerramenta.setAll(ferramentaDAO.listarTodos());
        tableFerramenta.setItems(ListaFerramenta);
    }

    @FXML
    void Cadastrar(ActionEvent event) {
        try {
            String tipo = txtTipo.getText();
            String marca = txtMarca.getText();
            String funcao = txtFuncao.getText();

            Ferramenta novoFerramenta = new Ferramenta(0, tipo, marca, funcao);
            ferramentaDAO.cadastrar(novoFerramenta);
            atualizarListaFerramenta();

            txtTipo.clear();
            txtMarca.clear();
            txtFuncao.clear();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Ferramenta salvo");
        } catch (NumberFormatException e) {
            exibirAlerta(Alert.AlertType.ERROR, "Erro", "Prencha todo os Campos");
        }
    }

    @FXML
    void Excluir(ActionEvent event) {
        Ferramenta selecionado = tableFerramenta.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            ferramentaDAO.excluir(selecionado.getId());
            atualizarListaFerramenta();
            exibirAlerta(Alert.AlertType.INFORMATION, "Ferramenta excluido", "");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione uma Ferramenta");
        }
        }

    @FXML
    void Alterar(ActionEvent event) {
        Ferramenta selecionado = tableFerramenta.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            txtTipo.setText(selecionado.getTipof());
            txtMarca.setText(selecionado.getMarcaf());
            txtFuncao.setText(selecionado.getFuncao());
        }
        else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione uma Ferramenta.");
        }

    }
    
    @FXML
    void Atualizar(ActionEvent event) {
        Ferramenta selecionado = tableFerramenta.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            selecionado.setTipof(txtTipo.getText());
            selecionado.setMarcaf(txtMarca.getText());
            selecionado.setFuncao(txtFuncao.getText());

            ferramentaDAO.atualizar(selecionado);
            atualizarListaFerramenta();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Ferramenta atualizado");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Erro", "Selecione uma Ferramenta");
        }
        }

    @FXML
    void MostrarMenu(ActionEvent event) throws IOException {
        App.setRoot("menu");

    }

    private void atualizarListaFerramenta() {
        ListaFerramenta.setAll(ferramentaDAO.listarTodos());
        tableFerramenta.refresh();
    }
} 
