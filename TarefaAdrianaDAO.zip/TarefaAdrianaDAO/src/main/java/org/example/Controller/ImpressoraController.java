package org.example.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.App;
import org.example.Classe.Impressora;
import org.example.DAO.ImpressoraDAO;

import java.io.IOException;

import static org.example.ExibirAlerta.exibirAlerta;

public class ImpressoraController {

 @FXML
    private Button btnAlterar;

    @FXML
    private Button btnAtualizar;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Button btnExcluirCac;

    @FXML
    private Button btn_menu;

    @FXML
    private TableColumn<Impressora, Integer> colId;

    @FXML
    private TableColumn<Impressora, String> colModelo;

    @FXML
    private TableColumn<Impressora, String> colPapel;

    @FXML
    private TableColumn<Impressora, Integer> colPreco;

    @FXML
    private TableView<Impressora> tableImpressora;

    @FXML
    private TextField txtModelo;

    @FXML
    private TextField txtPapel;

    @FXML
    private TextField txtPreco;

    private ObservableList<Impressora> ListaImpressora = FXCollections.observableArrayList();
    private ImpressoraDAO impressoraDAO = new ImpressoraDAO();

    @FXML
    private void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colModelo.setCellValueFactory(new PropertyValueFactory<>("modelo"));
        colPapel.setCellValueFactory(new PropertyValueFactory<>("papel"));
        colPreco.setCellValueFactory(new PropertyValueFactory<>("preco"));

        ListaImpressora.setAll(impressoraDAO.listarTodos());
        tableImpressora.setItems(ListaImpressora);
    }

    @FXML
    void Cadastrar(ActionEvent event) {
        try {
            String modelo = txtModelo.getText();
            String papel = txtPapel.getText();
            String preco = txtPreco.getText();

            Impressora novoImpressora = new Impressora(0, modelo, papel, Integer.parseInt(preco));
            impressoraDAO.cadastrar(novoImpressora);
            atualizarListaImpressora();

            txtModelo.clear();
            txtPapel.clear();
            txtPreco.clear();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Impressora salvo");
        } catch (NumberFormatException e) {
            exibirAlerta(Alert.AlertType.ERROR, "Erro", "Prencha todo os Campos");
        }
    }

    @FXML
    void Excluir(ActionEvent event) {
        Impressora selecionado = tableImpressora.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            impressoraDAO.excluir(selecionado.getId());
            atualizarListaImpressora();
            exibirAlerta(Alert.AlertType.INFORMATION, "Impressora excluida", "");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione uma Impressora");
        }
        }

    @FXML
    void Alterar(ActionEvent event) {
        Impressora selecionado = tableImpressora.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            txtModelo.setText(selecionado.getModelo());
            txtPapel.setText(selecionado.getPapel());
            txtPreco.setText(String.valueOf(selecionado.getPreco()));
        }
        else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione um Impressora.");
        }

    }
    
    @FXML
    void Atualizar(ActionEvent event) {
        Impressora selecionado = tableImpressora.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            selecionado.setModelo(txtModelo.getText());
            selecionado.setPapel(txtPapel.getText());
            selecionado.setPreco(Integer.parseInt(txtPreco.getText()));

            impressoraDAO.atualizar(selecionado);
            atualizarListaImpressora();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Impressora atualizado");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Erro", "Selecione um Impressora");
        }
        }

    @FXML
    void MostrarMenu(ActionEvent event) throws IOException {
        App.setRoot("menu");

    }

    private void atualizarListaImpressora() {
        ListaImpressora.setAll(impressoraDAO.listarTodos());
        tableImpressora.refresh();
    }
} 