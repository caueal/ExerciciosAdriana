package org.example.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.App;
import org.example.Classe.Caneta;
import org.example.DAO.CanetaDAO;

import java.io.IOException;

import static org.example.ExibirAlerta.exibirAlerta;

public class CanetaController {

 @FXML
    private Button btnAlterar;

    @FXML
    private Button btnAtualizar;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Button btnExcluirCac;

    @FXML
    private Button btn_menu;

    @FXML
    private TableColumn<Caneta, String> colCor;

    @FXML
    private TableColumn<Caneta, Integer> colId;

    @FXML
    private TableColumn<Caneta, String> colMarca;

    @FXML
    private TableColumn<Caneta, Double> colPreco;

    @FXML
    private TableView<Caneta> tableCaneta;

    @FXML
    private TextField txtCor;

    @FXML
    private TextField txtMarca;

    @FXML
    private TextField txtPreco;

    private ObservableList<Caneta> ListaCaneta = FXCollections.observableArrayList();
    private CanetaDAO canetaDAO = new CanetaDAO();

    @FXML
    private void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colCor.setCellValueFactory(new PropertyValueFactory<>("cor"));
        colMarca.setCellValueFactory(new PropertyValueFactory<>("marca"));
        colPreco.setCellValueFactory(new PropertyValueFactory<>("preco"));

        ListaCaneta.setAll(canetaDAO.listarTodos());
        tableCaneta.setItems(ListaCaneta);
    }

    @FXML
    void Cadastrar(ActionEvent event) {
        try {
            String cor = txtCor.getText();
            String marca = txtMarca.getText();
            String preco = txtPreco.getText();

            Caneta novoCaneta = new Caneta(0, cor, marca, Double.parseDouble(preco));
            canetaDAO.cadastrar(novoCaneta);
            atualizarListaCaneta();

            txtCor.clear();
            txtMarca.clear();
            txtPreco.clear();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Caneta salvo");
        } catch (NumberFormatException e) {
            exibirAlerta(Alert.AlertType.ERROR, "Erro", "Prencha todo os Campos");
        }
    }

    @FXML
    void Excluir(ActionEvent event) {
        Caneta selecionado = tableCaneta.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            canetaDAO.excluir(selecionado.getId());
            atualizarListaCaneta();
            exibirAlerta(Alert.AlertType.INFORMATION, "Caneta excluido", "");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione uma caneta");
        }
        }

    @FXML
    void Alterar(ActionEvent event) {
        Caneta selecionado = tableCaneta.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            txtCor.setText(selecionado.getCor());
            txtMarca.setText(selecionado.getMarca());
            txtPreco.setText(String.valueOf(selecionado.getPreco()));
        }
        else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione uma caneta.");
        }

    }
    
    @FXML
    void Atualizar(ActionEvent event) {
        Caneta selecionado = tableCaneta.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            selecionado.setCor(txtCor.getText());
            selecionado.setMarca(txtMarca.getText());
            selecionado.setPreco(Double.parseDouble(txtPreco.getText()));

            canetaDAO.atualizar(selecionado);
            atualizarListaCaneta();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Caneta atualizado");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Erro", "Selecione uma caneta");
        }
        }

    @FXML
    void MostrarMenu(ActionEvent event) throws IOException {
        App.setRoot("menu");

    }

    private void atualizarListaCaneta() {
        ListaCaneta.setAll(canetaDAO.listarTodos());
        tableCaneta.refresh();
    }
} 
