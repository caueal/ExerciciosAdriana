package org.example.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.App;
import org.example.Classe.Instrumento;
import org.example.DAO.InstrumentoDAO;

import java.io.IOException;

import static org.example.ExibirAlerta.exibirAlerta;

public class InstrumentoController {

    @FXML
    private Button btnSalvar;

 @FXML
    private Button btnAlterar;

    @FXML
    private Button btnAtualizar;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Button btnExcluirCac;

    @FXML
    private Button btn_menu;

    @FXML
    private TableColumn<Instrumento, Integer> colId;

    @FXML
    private TableColumn<Instrumento, String> colTipo;

    @FXML
    private TableColumn<Instrumento, String> colMaterial;

    @FXML
    private TableColumn<Instrumento, Double> colPreco;

    @FXML
    private TableView<Instrumento> tableInstrumento;

    @FXML
    private TextField txtTipo;

    @FXML
    private TextField txtMaterial;

    @FXML
    private TextField txtPreco;

    private ObservableList<Instrumento> ListaInstrumento = FXCollections.observableArrayList();
    private InstrumentoDAO InstrumentoDAO = new InstrumentoDAO();

    @FXML
    private void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTipo.setCellValueFactory(new PropertyValueFactory<>("tipo"));
        colMaterial.setCellValueFactory(new PropertyValueFactory<>("material"));
        colPreco.setCellValueFactory(new PropertyValueFactory<>("preco")); 

        ListaInstrumento.setAll(InstrumentoDAO.listarTodos());
        tableInstrumento.setItems(ListaInstrumento);
    }

    @FXML
    void Cadastrar(ActionEvent event) {
        try {
            String tipo = txtTipo.getText();
            String material = txtMaterial.getText();
            Double preco = Double.parseDouble(txtPreco.getText());

            Instrumento novoInstrumento = new Instrumento(0, tipo, material, preco);
            InstrumentoDAO.cadastrar(novoInstrumento);
            atualizarListaInstrumento();

            txtTipo.clear();
            txtMaterial.clear();
            txtPreco.clear();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Instrumento salvo");
        } catch (NumberFormatException e) {
            exibirAlerta(Alert.AlertType.ERROR, "Erro", "Prencha todo os Campos");
        }
    }

    @FXML
    void Excluir(ActionEvent event) {
        Instrumento selecionado = tableInstrumento.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            InstrumentoDAO.excluir(selecionado.getId());
            atualizarListaInstrumento();
            exibirAlerta(Alert.AlertType.INFORMATION, "Instrumento excluido", "");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione um Instrumento");
        }
        }

    @FXML
    void Alterar(ActionEvent event) {
        Instrumento selecionado = tableInstrumento.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            txtTipo.setText(selecionado.getTipo());
            txtMaterial.setText(selecionado.getMaterial());
            txtPreco.setText(String.valueOf(selecionado.getPreco()));
        }
        else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione um Instrumento.");
        }

    }
    
    @FXML
    void Atualizar(ActionEvent event) {
        Instrumento selecionado = tableInstrumento.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            selecionado.setTipo(txtTipo.getText());
            selecionado.setMaterial(txtMaterial.getText());
            selecionado.setPreco(Double.parseDouble(txtPreco.getText()));

            InstrumentoDAO.atualizar(selecionado);
            atualizarListaInstrumento();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Instrumento atualizado");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Erro", "Selecione uma Instrumento");
        }
        }

    @FXML
    void MostrarMenu(ActionEvent event) throws IOException {
        App.setRoot("menu");

    }

    private void atualizarListaInstrumento() {
        ListaInstrumento.setAll(InstrumentoDAO.listarTodos());
        tableInstrumento.refresh();
    }
} 
