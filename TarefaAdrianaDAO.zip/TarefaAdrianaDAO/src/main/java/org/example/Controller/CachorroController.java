package org.example.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.App;
import org.example.Classe.Cachorro;
import org.example.DAO.CachorroDAO;

import java.io.IOException;

import static org.example.ExibirAlerta.exibirAlerta;

public class CachorroController {

    @FXML
    private Button btnAlterar;

    @FXML
    private Button btnExcluirCac;

    @FXML
    private Button btnSalvar;

    @FXML
    private Button btn_menu;

    @FXML
    private TableColumn<Cachorro, Integer> colId;

    @FXML
    private TableColumn<Cachorro, String> colNome;

    @FXML
    private TableColumn<Cachorro, String> colRaca;

    @FXML
    private TableColumn<Cachorro, String> colPelugem;

    @FXML
    private TableView<Cachorro> tableCachorro;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtPelugem;

    @FXML
    private TextField txtRaca;


    // armazenamento dos dados observaveis
    private ObservableList<Cachorro> ListaCachorro = FXCollections.observableArrayList();
    private CachorroDAO cachorroDAO = new CachorroDAO();

    //preenche a tabela com os dados do banco de dados ao iniciar a tela
    @FXML
    private void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colRaca.setCellValueFactory(new PropertyValueFactory<>("raca"));
        colPelugem.setCellValueFactory(new PropertyValueFactory<>("pelugem")); //tem que ser o mesmo nome do atributo do BD

        ListaCachorro.setAll(cachorroDAO.listarTodos());
        tableCachorro.setItems(ListaCachorro);
    }

    //le os campos de texto e cria um novo objeto cachorro, que é salvo no bd
    @FXML
    void Cadastrar(ActionEvent event) {
        try {
            String nome = txtNome.getText();
            String raca = txtRaca.getText();
            String pelugem = txtPelugem.getText();

            Cachorro novoCachorro = new Cachorro(0, nome, raca, pelugem);
            cachorroDAO.cadastrar(novoCachorro);
            atualizarListaCachorro();

            txtNome.clear();
            txtRaca.clear();
            txtPelugem.clear();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Cachorro salvo");
        } catch (NumberFormatException e) {
            exibirAlerta(Alert.AlertType.ERROR, "Erro", "Prencha todo os Campos");
        }
    }

    //pega o cachorro selecionado na tabela e o exclui do banco de dados, com base no excluir método do CachorroDAO
    @FXML
    void Excluir(ActionEvent event) {
        Cachorro selecionado = tableCachorro.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            cachorroDAO.excluir(selecionado.getId());
            atualizarListaCachorro();
            exibirAlerta(Alert.AlertType.INFORMATION, "Cachorro excluido", "");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione um cachorro");
        }
        }

    //pega o cachorro selecionado na tabela e preenche os campos de texto com os dados dele, para que o usuario altere
    @FXML
    void Alterar(ActionEvent event) {
        Cachorro selecionado = tableCachorro.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            txtNome.setText(selecionado.getNome());
            txtRaca.setText(selecionado.getRaca());
            txtPelugem.setText(selecionado.getPelugem());
        }
        else {
            exibirAlerta(Alert.AlertType.WARNING, "Atenção", "Selecione um cachorro.");
        }

    }
    
    //pega o cachorro selecionado, atualiza os dados e chama o método atualizar do CachorroDAO para salvar as alterações no banco de dados e exibir
    @FXML
    void Atualizar(ActionEvent event) {
        Cachorro selecionado = tableCachorro.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            selecionado.setNome(txtNome.getText());
            selecionado.setRaca(txtRaca.getText());
            selecionado.setPelugem(txtPelugem.getText());

            cachorroDAO.atualizar(selecionado);
            atualizarListaCachorro();
            exibirAlerta(Alert.AlertType.INFORMATION, "Sucesso", "Cachorro atualizado");
        } else {
            exibirAlerta(Alert.AlertType.WARNING, "Erro", "Selecione um cachorro");
        }
        }


    //volta ao menu
    @FXML
    void MostrarMenu(ActionEvent event) throws IOException {
        App.setRoot("menu");

    }

    //recarrega a lista de cachorros da tabela
    private void atualizarListaCachorro() {
        ListaCachorro.setAll(cachorroDAO.listarTodos());
        tableCachorro.refresh();
    }
} 