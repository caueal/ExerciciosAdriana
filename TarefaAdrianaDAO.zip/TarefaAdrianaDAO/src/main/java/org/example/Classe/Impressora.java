package org.example.Classe;

public class Impressora {
    private int id; 
    private String modelo; 
    private String papel; 
    private Integer preco; 

    public Impressora(int id, String modelo, String papel, Integer preco) {
    this.id = id; 
    this.modelo = modelo; 
    this.papel = papel; 
    this.preco = preco; 
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getPapel() {
        return papel;
    }

    public void setPapel(String papel) {
        this.papel = papel;
    }

    public Integer getPreco() {
        return preco;
    }

    public void setPreco(Integer preco) {
        this.preco = preco;
    }

    
}
