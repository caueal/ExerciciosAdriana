package org.example.Classe;

public class Caneta {
    private int id;
    private String cor;
    private String marca;
    private double preco;

    public Caneta(int id, String cor, String marca, double preco) {
        this.id = id;
        this.cor = cor;
        this.marca = marca;
        this.preco = preco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
    
}
