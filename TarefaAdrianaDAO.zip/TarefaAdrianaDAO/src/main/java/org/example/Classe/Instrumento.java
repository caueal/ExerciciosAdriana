package org.example.Classe;

public class Instrumento {
    private int id; 
    private String tipo; 
    private String material; 
    private Double preco;

    public Instrumento(int id, String tipo, String material, Double preco) {
        this.id = id;
        this.tipo = tipo;
        this.material = material;
        this.preco = preco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }
    
}

