package org.example.Classe;

public class Cachorro {
    private int id;
    private String nome;
    private String raca;
    private String pelugem;

    public Cachorro(int id, String nome, String raca, String pelugem) {
        this.id = id;
        this.nome = nome;
        this.raca = raca;
        this.pelugem = pelugem;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getPelugem() {
        return pelugem;
    }

    public void setPelugem(String pelugem) {
        this.pelugem = pelugem;
    }

}