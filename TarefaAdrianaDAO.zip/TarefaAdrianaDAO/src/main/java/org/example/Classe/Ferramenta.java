package org.example.Classe;

public class Ferramenta {
    private int id; 
    private String tipof;
    private String marcaf;
    private String funcao;

    public Ferramenta(int id, String tipof, String marcaf, String funcao) {
        this.id = id;
        this.tipof = tipof;
        this.marcaf = marcaf;
        this.funcao = funcao; 
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipof() {
        return tipof;
    }

    public void setTipof(String tipof) {
        this.tipof = tipof;
    }

    public String getMarcaf() {
        return marcaf;
    }

    public void setMarcaf(String marcaf) {
        this.marcaf = marcaf;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
   
}
